/********************************************************************************
** Form generated from reading UI file 'networkanalysiswindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NETWORKANALYSISWINDOW_H
#define UI_NETWORKANALYSISWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NetworkAnalysisWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout_2;
    QPushButton *btnMutualFollowers;
    QTextEdit *textEdit;
    QPushButton *btnSuggest;
    QPushButton *btnMostInfluencer;
    QPushButton *btnMostActive;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *NetworkAnalysisWindow)
    {
        if (NetworkAnalysisWindow->objectName().isEmpty())
            NetworkAnalysisWindow->setObjectName("NetworkAnalysisWindow");
        NetworkAnalysisWindow->resize(658, 451);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(NetworkAnalysisWindow->sizePolicy().hasHeightForWidth());
        NetworkAnalysisWindow->setSizePolicy(sizePolicy);
        NetworkAnalysisWindow->setMinimumSize(QSize(300, 400));
        centralwidget = new QWidget(NetworkAnalysisWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setMinimumSize(QSize(0, 0));
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName("gridLayout_3");
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName("gridLayout_2");
        btnMutualFollowers = new QPushButton(centralwidget);
        btnMutualFollowers->setObjectName("btnMutualFollowers");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(btnMutualFollowers->sizePolicy().hasHeightForWidth());
        btnMutualFollowers->setSizePolicy(sizePolicy1);
        btnMutualFollowers->setMinimumSize(QSize(150, 50));

        gridLayout_2->addWidget(btnMutualFollowers, 2, 1, 1, 1);

        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName("textEdit");
        sizePolicy1.setHeightForWidth(textEdit->sizePolicy().hasHeightForWidth());
        textEdit->setSizePolicy(sizePolicy1);
        textEdit->setMinimumSize(QSize(300, 256));

        gridLayout_2->addWidget(textEdit, 1, 0, 4, 1);

        btnSuggest = new QPushButton(centralwidget);
        btnSuggest->setObjectName("btnSuggest");
        sizePolicy1.setHeightForWidth(btnSuggest->sizePolicy().hasHeightForWidth());
        btnSuggest->setSizePolicy(sizePolicy1);
        btnSuggest->setMinimumSize(QSize(150, 50));

        gridLayout_2->addWidget(btnSuggest, 4, 1, 1, 1);

        btnMostInfluencer = new QPushButton(centralwidget);
        btnMostInfluencer->setObjectName("btnMostInfluencer");
        sizePolicy1.setHeightForWidth(btnMostInfluencer->sizePolicy().hasHeightForWidth());
        btnMostInfluencer->setSizePolicy(sizePolicy1);
        btnMostInfluencer->setMinimumSize(QSize(150, 50));

        gridLayout_2->addWidget(btnMostInfluencer, 3, 1, 1, 1);

        btnMostActive = new QPushButton(centralwidget);
        btnMostActive->setObjectName("btnMostActive");
        sizePolicy1.setHeightForWidth(btnMostActive->sizePolicy().hasHeightForWidth());
        btnMostActive->setSizePolicy(sizePolicy1);
        btnMostActive->setMinimumSize(QSize(150, 50));

        gridLayout_2->addWidget(btnMostActive, 1, 1, 1, 1);


        gridLayout_3->addLayout(gridLayout_2, 0, 0, 1, 1);

        NetworkAnalysisWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(NetworkAnalysisWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 658, 22));
        NetworkAnalysisWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(NetworkAnalysisWindow);
        statusbar->setObjectName("statusbar");
        NetworkAnalysisWindow->setStatusBar(statusbar);

        retranslateUi(NetworkAnalysisWindow);

        QMetaObject::connectSlotsByName(NetworkAnalysisWindow);
    } // setupUi

    void retranslateUi(QMainWindow *NetworkAnalysisWindow)
    {
        NetworkAnalysisWindow->setWindowTitle(QCoreApplication::translate("NetworkAnalysisWindow", "NetworkAnalysisWindow", nullptr));
        btnMutualFollowers->setText(QCoreApplication::translate("NetworkAnalysisWindow", "Mutual Followers", nullptr));
        btnSuggest->setText(QCoreApplication::translate("NetworkAnalysisWindow", "Suggest", nullptr));
        btnMostInfluencer->setText(QCoreApplication::translate("NetworkAnalysisWindow", "Most Influencer", nullptr));
        btnMostActive->setText(QCoreApplication::translate("NetworkAnalysisWindow", "Most Active", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NetworkAnalysisWindow: public Ui_NetworkAnalysisWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NETWORKANALYSISWINDOW_H
